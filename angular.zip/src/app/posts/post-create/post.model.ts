export interface Ingredient {
  name: string;
  quantity: string;
}
