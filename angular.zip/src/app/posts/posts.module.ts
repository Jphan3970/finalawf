import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";

import { PostCreateComponent } from "./post-create/post-create.component";
import { PostListComponent } from "./post-list/post-list.component";
import { AngularMaterialModule } from "../angular-material.module";
import { PostIngredientComponent } from "./post-create/post-ingredient/post-ingredient.component";
import { MatTableModule } from '@angular/material'

@NgModule({
  declarations: [PostCreateComponent, PostListComponent, PostIngredientComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    AngularMaterialModule,
    RouterModule,
    MatTableModule
  ],
  exports:[ MatTableModule ]
})
export class PostsModule {}
